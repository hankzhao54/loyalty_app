# Handoff: 101 Members — Loyalty App Visual Refresh

## Overview
A visual redesign of the **101 Members** loyalty app (101 Bao group, Budapest — 5 locations).
It restyles the existing app with a younger, more energetic look and adds two new global controls:
a **EN / HU language switch** and a **day / night theme switch**. All existing screens and
functionality are preserved — only the presentation and the two switches are new.

The app has five tabs (bottom navigation): **Card, Rewards, Stamps, Staff, Admin**.

## About the Design Files
The files in this bundle are **design references created in HTML** — a prototype showing the
intended look and behavior. They are **not production code to copy directly**.

The task is to **recreate this design in the existing codebase** (the live app runs on Vercel —
appears to be a React / Next.js project) using its established components, routing, state, and
i18n patterns. Apply the visual spec below to the real screens. Do not ship the HTML file itself.

The HTML prototype was authored with an internal templating runtime (`support.js`, `.dc.html`).
Ignore that runtime — read the markup and the logic class (`class Component`) purely as a
**specification of layout, tokens, copy, and behavior**.

## Fidelity
**High-fidelity (hifi).** Final colors, typography, spacing, radii, and interactions are all
specified below with exact values. Recreate pixel-faithfully using the codebase's own component
library. The phone bezel / status bar in the prototype is just presentational framing — ignore it.

---

## Design Tokens

Two themes. All UI reads from these tokens (in the prototype they are CSS variables set per render).

### Light theme (default / "day") — tomato red
| Token | Value | Use |
|---|---|---|
| bg | `#FBF7F2` | screen background |
| text | `#1A1614` | primary text |
| muted | `#9a8f88` (lists: `#b0a69e`) | secondary text |
| surface | `#FFFFFF` | cards / panels |
| line | `#f0e9e2` (inner dividers `#f2ece5`) | borders / dividers |
| accent | `#FF5630` | primary brand / buttons / active |
| accentInk | `#FFFFFF` | text/icons on accent |
| cardBg | `#FF5630` | membership card bg |
| cardText | `#FFFFFF` | text on membership card |
| cardMuted | `#ffd9ce` | secondary text on card |
| badgeBg | `#FFFFFF` | tier badge bg |
| badgeText | `#FF5630` | tier badge text |
| green | `#1FA463` | positive point deltas |
| qrInk | `#1A1614` | QR code dark modules |

### Night theme ("night") — warm gold on dark
| Token | Value |
|---|---|
| bg | `#171210` |
| text | `#F2EBE0` |
| muted | `#a08f80` |
| surface | `#211915` |
| line | `#2e231d` |
| accent | `#E8A85C` |
| accentInk | `#2a1409` |
| cardBg | `linear-gradient(140deg,#F0C778 0%,#D99A4E 55%,#C77E3A 100%)` |
| cardText | `#2a1409` |
| cardMuted | `#6b3a1d` |
| badgeBg | `#2a1409` |
| badgeText | `#F0C778` |
| green | `#7BD389` |
| qrInk | `#2a1409` |

### Typography
- **Display / numbers:** `Space Grotesk`, weight 700 (titles, point balances, stats). Titles letter-spacing `-0.5px`.
- **Body / UI:** `Outfit` (latin) with `Noto Sans SC` fallback for CJK, weights 400/600/700.
- **Mono (IDs, dates, nav labels, codes):** `Space Mono`, 11–12px.
- Sizes: screen title 24px/700; section heading 15px/700; card label 12px; body 14px;
  caption 11–12px; membership balance 48px/700; rewards balance 38px/700; stat numbers 22px/700.

### Spacing / shape
- Screen horizontal padding: 22px. Content top padding 6px, bottom padding 90px (clears nav).
- Card radius: 28px (membership), 22–24px (panels), 20px (small), 16–20px (chips/buttons), 12–13px (inputs).
- Panel border: `1px solid line`. Inputs: `1px solid line`, bg = `bg` token, radius 12–13px, padding ~13px.
- Buttons (primary): bg `accent`, text `accentInk`, radius 14px, padding 14px, weight 700, centered.
- Gaps use flex/grid `gap`, never margins between siblings.

---

## Global Chrome

### Header (every tab)
- Left: screen **title** (24px/700 Space Grotesk) + **subtitle** (12px muted). Both are localized.
- Right: a control cluster (`display:flex; gap:8px`):
  - **Language segmented control**: rounded 10px, `surface` bg, `1px solid line`, Space Mono 11px/700.
    Two segments `EN` / `HU`. Active segment: bg `accent`, text `accentInk`. Inactive: transparent, text `muted`.
  - **Theme toggle**: 52×30 pill, `surface` bg, `1px solid line`. 22px knob, bg `accent`, 3px inset.
    Knob `translateX(0)` in day, `translateX(22px)` in night, `transition: transform .3s ease`.
    Knob holds a small sun (filled white dot) in day; a crescent (dot with offset box-shadow) in night.

### Bottom navigation (every tab)
- Fixed bottom bar, height 74px, bg = `navBg` (translucent screen bg) + `backdrop-filter: blur(8px)`,
  top border `1px solid line`, `padding-bottom:8px`.
- 5 items, Space Mono 12px, evenly spaced: **Card · Rewards · Stamps · Staff · Admin** (labels stay English).
- Active item: text `text`, weight 700, `border-bottom:2px solid accent`, `padding-bottom:3px`.
  Inactive: text `muted`, weight 400, transparent bottom border.

### Theme transition
- The screen background transitions with `transition: background-color .35s ease`.
  ⚠️ **Implementation note / gotcha:** animate `background-color` (and `color`) — **not** the `background`
  shorthand — when the value comes from a CSS variable, or Chrome strands it on the fallback color.

---

## Screens / Views

### 1. Card (default tab)
Purpose: member sees their card, balance, tier progress, recent activity.
- **Membership card** (cardBg, radius 28px, padding 22px, `overflow:hidden`):
  - Decorative: a translucent white circle bottom-left (150px, `rgba(255,255,255,.13)`); a giant
    `101` watermark bottom-right (Space Grotesk 80px, `rgba(255,255,255,.13)`).
  - Top row: left = email `staff@test.com` (15px/700 cardText) + member id `LY-2026-000003`
    (Space Mono 12px cardMuted). Right = tier badge **Gold** (badgeBg pill, badgeText, 12px/700).
  - Bottom row: left = label (Available points) 12px cardMuted, **5,605** (Space Grotesk 48px/700 cardText),
    hint line (qr hint) 11px cardMuted. Right = **QR code** 88×88 white tile, radius 12px, padding 7px,
    with 3 finder squares (the prototype fakes it with a conic-gradient + 3 bordered squares;
    in production render the member's real QR).
- **Annual tier panel** (surface card): row → label (Annual tier points) + value `5,555` (accent, 18px/700).
  Progress bar: 8px tall, track `line`, fill 100% `accent`, radius 8px. Caption (tier status) 12px muted.
- **Recent activity**: heading (15px/700) then a surface card list. Each row: left = title (14px/600) +
  date (Space Mono 11px muted); right = delta (Space Grotesk 15px/700 `green`). Rows divided by `line`.
  - Row 1: "Purchase 555 555 HUF · 101 Bao" / 23/06/2026 / **+5555**
  - Row 2: "Signup bonus" / 12/06/2026 / **+50**

### 2. Rewards
Purpose: see redeemable balance and the redemption menu.
- **Balance banner** (cardBg, radius 22px): label (Available points) 12px cardMuted, `5,605` (38px/700 cardText),
  decorative translucent circle top-right.
- **Redeem points** heading, then a surface list card. Each row: a 4px×30px accent tick bar, the reward
  name (14px/600), and a points pill (Space Grotesk 13px/700, bg accent, accentInk, radius 16px).
  - One drink — 60 pts
  - Spring rolls — 80 pts
  - 15% off signature — 150 pts
  - Quarter roast duck — 300 pts
- Footer caption (voucher hint), centered, 12px muted.

### 3. Stamps
Purpose: stamp-card collection + multi-store campaign.
- **Dining stamp card** (surface, radius 24px): header title + count `1/8 stamps` (accent 13px/700);
  desc 12px muted. Grid of 8 circles (`grid-template-columns:repeat(4,1fr); gap:14px`, `aspect-ratio:1`).
  Filled stamp = bg `accent`, accentInk, a CJK good-fortune character (福禄壽喜滿豐餘圓 — brand decoration,
  keep as-is), Noto Sans SC 22px/700. Empty = `2px dashed line` border, muted character.
  Currently 1 of 8 filled.
- **Five-store tour** (surface, radius 24px): header title + count `1/5 stores`; desc 12px muted.
  List of 5 rows, each: a 22px status dot (done = bg `green`, white ✓; pending = `2px solid line` ring)
  + store name (14px/600; done = text color, pending = muted).
  Stores: 101 Bao (done), 101 Bistro, 101 Neo, 101 Tigris, 101 Timeout.

### 4. Staff (store console)
Purpose: staff records purchases and verifies vouchers.
- **Stat strip** (surface, radius 20px, 3 equal cells divided by `line`): each = number 22px/700 + label
  11px muted. Labels: Entries / Points given / Verified. All `0` in the mock.
- **Record a purchase** (surface panel): heading 15px/700, then inputs (each input: bg `bg`, `1px solid line`,
  radius 13px, 13px padding, 14px text):
  - Row: card-number text input ("Card number (e.g. 26000128)") + a **Scan** button (outline accent).
  - Amount input ("Amount (HUF)").
  - Store select (101 Bao / Bistro / Neo / Tigris / Timeout).
  - Primary **Record purchase** button (full width).
- **Verify a voucher** (surface panel): heading + row of code input ("RWD-XXXXXX") + filled **Verify** button.

### 5. Admin (rewards management)
Purpose: create/manage the rewards catalog.
- **New reward** form (surface panel):
  - Name label ("Name (EN required / HU / 中)"), then `EN *` input, then a row of `HU` + `中` inputs.
  - Row: Points cost input (placeholder 60) + Stock limit input (placeholder ∞).
  - Row: Type select (Free item / Discount) + Min tier select (Silver / Gold).
  - Checkbox row: a filled 22px accent check + "Visible to members".
  - Primary **Create** button (full width).
- **Current catalog** (surface list): heading, then rows divided by `line`. Each: name (14px/600;
  hidden items use muted color) + meta (Space Mono 11px muted), and two 30px square action buttons
  ✎ (edit, muted) and ✕ (delete, `#d9544e`).
  - One drink — 60 · Free item
  - Spring rolls — 80 · Free item
  - 15% off signature — 150 · Discount
  - Quarter roast duck — 300 · Free item
  - Five-store tour gift · hidden — 999 999 · Free item (rendered muted)

---

## Interactions & Behavior
- **Tab nav**: clicking a bottom-nav item switches the active tab (client-side; no reload). Active styling per spec.
- **Language switch**: toggles `lang` between `en` / `hu`. Re-renders ALL copy across every tab. Nav labels
  and brand strings (101, store names, the CJK stamp characters, "Gold", member id, QR) stay as-is.
  Default = `en`.
- **Theme switch**: toggles `dark`. Swaps the full token set; knob slides; background-color transitions .35s.
- All buttons/inputs in the mock are non-functional placeholders — wire them to the real app's
  existing handlers (record purchase, verify voucher, redeem, create/edit/delete reward).

## State Management
- `tab`: 'card' | 'rewards' | 'stamps' | 'staff' | 'admin' (default 'card').
- `lang`: 'en' | 'hu' (default 'en').
- `dark`: boolean (default false).
- Recommended: persist `lang` and `dark` (localStorage or user profile) so they survive reloads —
  not implemented in the mock; the live app likely already has i18n + user settings to hook into.
- Real data to bind: member email, member id, tier, available points, annual tier points + progress,
  recent activity feed, redeemable rewards list, stamp progress, five-store progress, staff stats,
  admin catalog. The numbers in the mock are sample values.

## Localization
Full EN + HU strings are in the prototype's logic class (`Member App.dc.html`, the `EN` and `HU`
objects in `renderVals()`). Use them as the translation source of truth — copy the HU strings verbatim
into the app's i18n catalog. Staff/Admin are operational screens but are also fully translated.
A `中` (Chinese) name field exists only in the Admin reward-creation form (the catalog stores names in
3 languages); the member-facing UI is EN/HU only.

## Assets
- **Fonts**: Space Grotesk, Outfit, Noto Sans SC, Space Mono (Google Fonts). Swap for the app's own
  font stack if it has one; otherwise import these.
- **No bitmap/icon assets** — all glyphs (QR, stamps, status dots, sun/moon, ✎ ✕ ✓) are drawn with
  CSS/markup or simple characters. Use the app's real QR generator and its icon set in production.
- **CJK fortune characters** on stamps (福禄壽喜滿豐餘圓) are intentional 101 Bao brand decoration.

## Files
- `Member App.dc.html` — the full hifi prototype (all 5 tabs, both themes, both languages). Primary reference.
- `Member App Directions.dc.html` — the earlier 3 visual-direction explorations (A neon/lime, B warm-dark,
  C bright/tomato). The final app uses **C as the day theme and B as the night theme**. Background context only.
